<?php

namespace App\Http\Controllers\frontendController;

abstract class Controller
{
    //
}
