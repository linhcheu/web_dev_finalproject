

<?php $__env->startSection('title', 'All Feedback - CareConnect'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="page-header" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); padding: 2.5rem 0; margin-bottom: 3rem;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="text-white mb-2"><i class="fas fa-comments me-2"></i>Community Feedback</h1>
                <p class="text-white-50 mb-0">Discover what our users are saying about their healthcare experiences</p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <a href="<?php echo e(route('user.feedback')); ?>" class="btn btn-light"><i class="fas fa-plus-circle me-2"></i>Share Your Feedback</a>
            </div>
        </div>
    </div>
</div>

<div class="container py-4">
    <!-- Filters -->
    <div class="card shadow-sm mb-4 border-0 overflow-hidden">
        <div class="card-header bg-white py-3">
            <h5 class="mb-0"><i class="fas fa-filter me-2 text-primary"></i>Filter Feedback</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('all.feedback')); ?>" method="GET">
                <div class="row g-3">
                    <div class="col-md-9">
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0">
                                <i class="fas fa-search text-muted"></i>
                            </span>
                            <input type="text" class="form-control border-start-0" id="search" name="search" 
                                placeholder="Search by name or keyword..." value="<?php echo e(request('search')); ?>">
                        </div>
                    </div>
                    <div class="col-md-3 d-flex">
                        <button type="submit" class="btn btn-primary flex-grow-1">
                            <i class="fas fa-filter me-2"></i>Search
                        </button>
                        <a href="<?php echo e(route('all.feedback')); ?>" class="btn btn-outline-secondary ms-2">
                            <i class="fas fa-redo"></i>
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Feedback Section -->
    <div class="feedback-grid">
        <?php if($feedback->count() > 0): ?>
            <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="feedback-card">
                    <div class="card-inner">
                        <div class="user-info">
                            <div class="avatar-container">
                                <?php if($item->user->profile_picture): ?>
                                    <img src="<?php echo e(asset('storage/' . $item->user->profile_picture)); ?>" alt="Profile" 
                                        class="rounded-circle">
                                <?php else: ?>
                                    <div class="avatar-placeholder">
                                        <?php echo e(strtoupper(substr($item->user->first_name, 0, 1))); ?><?php echo e(strtoupper(substr($item->user->last_name, 0, 1))); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div>
                                <h6 class="user-name"><?php echo e($item->user->first_name); ?> <?php echo e($item->user->last_name); ?></h6>
                                <small class="date-info"><i class="far fa-clock me-1"></i><?php echo e($item->created_at->diffForHumans()); ?></small>
                            </div>
                        </div>
                        
                        <div class="feedback-content">
                            <i class="fas fa-quote-left quote-icon start"></i>
                            <p class="feedback-text"><?php echo e($item->comments); ?></p>
                            <i class="fas fa-quote-right quote-icon end"></i>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-comments fa-4x text-muted mb-3"></i>
                <h4>No Feedback Available</h4>
                <p class="text-muted">We couldn't find any feedback matching your criteria.</p>
                <?php if(request('search')): ?>
                    <a href="<?php echo e(route('all.feedback')); ?>" class="btn btn-outline-primary mt-3">
                        <i class="fas fa-redo me-2"></i>Clear Filters
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('user.feedback')); ?>" class="btn btn-primary mt-3">
                        <i class="fas fa-plus-circle me-2"></i>Be the First to Share
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    /* Page Header */
    .page-header {
        position: relative;
        overflow: hidden;
    }

    .page-header::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB2aWV3Qm94PSIwIDAgMTI4MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjEpIj48cGF0aCBkPSJNMTI4MCAxNDBWMFM5OTMuNDYgMTQwIDY0MCAxMzkgMCAwIDAgMHYxNDB6Ii8+PC9nPjwvc3ZnPg==');
        background-size: 100% 100px;
        background-position: bottom;
        z-index: 1;
    }

    .page-header .container {
        position: relative;
        z-index: 2;
    }
    
    /* Feedback Grid - Explicitly 5 per row */
    .feedback-grid {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 20px;
    }
    
    /* Empty state styling */
    .empty-state {
        grid-column: 1 / -1; /* Span all columns */
        text-align: center;
        background-color: #fff;
        border-radius: 16px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        padding: 40px 20px;
    }
    
    /* Feedback Cards */
    .feedback-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        height: 100%;
    }
    
    .feedback-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }
    
    .card-inner {
        padding: 20px;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    
    .user-info {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 15px;
    }
    
    .avatar-container {
        flex-shrink: 0;
    }
    
    .avatar-container img {
        width: 40px;
        height: 40px;
        object-fit: cover;
    }
    
    .avatar-placeholder {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 12px;
    }
    
    .user-name {
        margin: 0;
        font-size: 0.9rem;
        font-weight: 600;
        color: #2d3748;
        line-height: 1.2;
    }
    
    .date-info {
        color: #718096;
        font-size: 0.75rem;
    }
    
    .feedback-content {
        flex-grow: 1;
        position: relative;
        padding: 0.5rem 0;
    }
    
    .quote-icon {
        color: var(--primary-color);
        opacity: 0.15;
        font-size: 0.9rem;
        position: absolute;
    }
    
    .quote-icon.start {
        top: 0;
        left: 0;
    }
    
    .quote-icon.end {
        bottom: 0;
        right: 0;
    }
    
    .feedback-text {
        padding: 0 16px;
        margin: 0;
        color: #4b5563;
        font-style: italic;
        font-size: 0.85rem;
        line-height: 1.5;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 5;
        -webkit-box-orient: vertical;
    }
    
    /* Custom styling for filters */
    .input-group .form-control:focus,
    .form-select:focus {
        box-shadow: none;
        border-color: var(--primary-color);
    }
    
    .form-control::placeholder {
        color: #9ca3af;
        font-size: 14px;
    }
    
    /* Responsive adjustments */
    @media (max-width: 1199.98px) {
        .feedback-grid {
            grid-template-columns: repeat(4, 1fr);
        }
    }
    
    @media (max-width: 991.98px) {
        .feedback-grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }
    
    @media (max-width: 767.98px) {
        .feedback-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .page-header {
            padding: 2rem 0;
        }
    }
    
    @media (max-width: 575.98px) {
        .feedback-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
<?php $__env->stopSection(); ?>
      
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Desktop\careconnect_boss\frontend\resources\views/all_feedback.blade.php ENDPATH**/ ?>