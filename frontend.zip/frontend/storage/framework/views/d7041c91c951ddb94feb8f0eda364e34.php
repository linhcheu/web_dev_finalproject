

<?php $__env->startSection('title', 'Test Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-header">
                    <h2>JavaScript Test</h2>
                </div>
                <div class="card-body">
                    <form id="testForm">
                        <div class="form-group">
                            <label for="testInput">Test Input</label>
                            <input type="text" id="testInput" name="testInput" class="form-control" value="Test Value" disabled>
                        </div>
                        
                        <div class="form-actions" id="testFormActions" style="display: none;">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <button type="button" class="btn btn-secondary" onclick="cancelTestEdit()">Cancel</button>
                        </div>
                    </form>
                    
                    <button type="button" class="btn btn-outline" onclick="toggleTestEdit()">
                        <i class="fas fa-edit"></i>
                        Edit
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
let isTestEditing = false;

function toggleTestEdit() {
    console.log('=== toggleTestEdit function called ===');
    
    const form = document.getElementById('testForm');
    const actions = document.getElementById('testFormActions');
    const input = document.getElementById('testInput');
    
    console.log('Form element:', form);
    console.log('Actions element:', actions);
    console.log('Input element:', input);
    
    if (!isTestEditing) {
        // Enable editing
        console.log('Enabling test editing...');
        input.disabled = false;
        console.log('Enabled input:', input.name);
        
        actions.style.display = 'block';
        actions.style.visibility = 'visible';
        actions.style.opacity = '1';
        
        isTestEditing = true;
        console.log('Test editing enabled');
    } else {
        // Disable editing
        console.log('Disabling test editing...');
        input.disabled = true;
        
        actions.style.display = 'none';
        isTestEditing = false;
        console.log('Test editing disabled');
    }
}

function cancelTestEdit() {
    console.log('=== cancelTestEdit function called ===');
    
    const input = document.getElementById('testInput');
    const actions = document.getElementById('testFormActions');
    
    input.disabled = true;
    actions.style.display = 'none';
    isTestEditing = false;
    console.log('Test editing cancelled');
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('=== Test Page DOM Content Loaded ===');
    
    const input = document.getElementById('testInput');
    const actions = document.getElementById('testFormActions');
    
    input.disabled = true;
    actions.style.display = 'none';
    
    console.log('Test input disabled:', input.disabled);
    console.log('Test actions display:', actions.style.display);
    console.log('=== Test Page Initialization complete ===');
});
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Desktop\careconnect_boss\frontend\resources\views/test.blade.php ENDPATH**/ ?>